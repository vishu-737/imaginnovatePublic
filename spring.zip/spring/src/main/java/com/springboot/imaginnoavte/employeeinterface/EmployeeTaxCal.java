package com.springboot.imaginnoavte.employeeinterface;

public interface EmployeeTaxCal {
	
	public int taxToBePaid(float salary);

}
