package com.springboot.imaginnoavte.employeeinterface.serviceimpl;

import org.springframework.stereotype.Service;

import com.springboot.imaginnoavte.employeeinterface.EmployeeTaxCal;

@Service
public class EmployeeTacCalClass implements EmployeeTaxCal{

	@Override
	public int taxToBePaid(float salary) {
		int taxPaid = 0;
		if (salary > 250000 && salary <= 500000) {
			taxPaid = (taxPaid + (250000 * 5 / 100));
		}
		if (salary > 500000 && salary <= 1000000) {
			taxPaid = (taxPaid + (500000 * 10 / 100));
		}
		if (salary > 1000000) {
			taxPaid = (taxPaid + (1000000 * 15 / 100));
		}
		return taxPaid;
	}

}
