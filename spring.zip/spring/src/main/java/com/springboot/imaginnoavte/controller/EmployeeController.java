package com.springboot.imaginnoavte.controller;

import java.util.Calendar;
import java.util.Date;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.imaginnoavte.employeeDTO.Employee;
import com.springboot.imaginnoavte.employeeDTO.EmployeeDTO;
import com.springboot.imaginnoavte.employeeinterface.EmployeeTaxCal;




@RestController
@RequestMapping("/api/imaginnovate")
public class EmployeeController {
	
	@Autowired
	private EmployeeTaxCal employeeTaxCal;
	
	@GetMapping("/v1/getTaxDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public ResponseEntity<EmployeeDTO> getTaxDetails(@Valid @RequestBody Employee employee) {
		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setEmployeeID(employee.getEmployeeID());
		employeeDTO.setFirstName(employee.getFirstName());
		employeeDTO.setLastName(employee.getLastName());
		
		float salary = employee.getSalary()*12;
		
		employeeDTO.setYearlySalary((int) salary);
		
		 int daysLateJoined = daysBetween(employee.getDateOfJoining(), new Date());
		if(daysLateJoined > 0) {
			float salaryInDay = salary/30;
			int dayToBeDeducted = 365 - daysLateJoined;
			salary = salaryInDay * dayToBeDeducted;
			employeeDTO.setYearlySalary((int) salary);
		}
		
		if(salary <= 250000) {
			employeeDTO.setTaxAmount(0);
		}else {
		int taxPaid = employeeTaxCal.taxToBePaid(salary);
		employeeDTO.setTaxAmount(taxPaid);
		}
		
		if (employee.getSalary() * 12 > 2500000) {
			int cess = (int) ((employee.getSalary() - 2500000) * 3 / 100);
			employeeDTO.setCessAmount(cess);
		}
		
		return new ResponseEntity<>(employeeDTO,HttpStatus.OK);
	}
	
	
	private int daysBetween(Date d1, Date d2) {
		int difference = 0;

		if (d1 != null && d2 != null) {
			Calendar earlier = Calendar.getInstance();
			Calendar later = Calendar.getInstance();

			if (d1.compareTo(d2) < 0) {
				earlier.setTime(nullifyTime(d1));
				later.setTime(nullifyTime(d2));
			} else {
				earlier.setTime(nullifyTime(d2));
				later.setTime(nullifyTime(d1));
			}

			while (earlier.before(later)) {
				earlier.add(Calendar.DAY_OF_MONTH, 1);
				difference++;
			}
		}
		return difference;
	}
	
	private Date nullifyTime(Date a) {
		Calendar c = Calendar.getInstance();
		c.setTime(a);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);

		return c.getTime();
	}
	
}
